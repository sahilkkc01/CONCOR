import React, { useState, useEffect } from 'react'

export default function Map() {
    const [zoomLevel, setZoomLevel] = useState(0.2); // Default Zoomed Out (-0.2 from 1)

    // Zoom In Function
    const handleZoomIn = () => {
        if (zoomLevel < 5) {
            setZoomLevel(prev => prev + 0.2);
        }
    };

    // Zoom Out Function
    const handleZoomOut = () => {
        if (zoomLevel > 0.2) { // Prevents zooming out too much
            setZoomLevel(prev => prev - 0.2);
        }
    };
    // maps fill color
    useEffect(() => {
        const ids = ['zs90_1', 'zs90_2', 'zs90_3']; // IDs list
        ids.forEach(id => {
            const element = document.getElementById(id);
            console.log(id);
            console.log(element);
            if (element) {
                element.style.setProperty('background-color', '#8f51dd', 'important');

            }
        });
    }, []);

    return (
        <>
            <div className="m-auto vh-100 vw-100">

                {/* Fixed Zoom Buttons at the Top Center */}
                <div className="d-flex gap-3 p-2 bg-light shadow position-fixed top-0 start-50 translate-middle-x rounded mt-2 z-3">
                    <button
                        onClick={handleZoomIn}
                        className="btn btn-success"
                    >
                        +
                    </button>
                    <button
                        onClick={handleZoomOut}
                        className="btn btn-danger"
                    >
                        -
                    </button>
                </div>

                {/* Full-Screen Map */}
                <div
                >
                    <div
                        className="position-absolute top-0 start-0 w-100 h-100 bg-center"
                        style={{
                            backgroundSize: 'cover',
                            transform: `scale(${zoomLevel})`,
                            transformOrigin: 'center center',
                            transition: 'transform 0.3s ease-in-out',
                        }}
                    >
                        <h1 className='text-center mt-2' >Export Warehouse</h1>
                        <div className='d-flex ms-4 mb-0 mt-5'>
                            <div className="main  py-1 px-1 bg-dark d-flex flex-column  border-light border border-2 position-relative"
                            >
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zs90" style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZS90
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex ">
                                    <div id="zs90_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zs90_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zs90_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zs90_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zs90_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zs90_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zs90_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zs90_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zs90_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zs90_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zs90_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zs90_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zs90_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zs90_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zs90_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zs90_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zs90_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zs90_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zs90_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zs90_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>

                            </div>
                            <div className="main  py-1 px-1 bg-light  border-light border border-2" style={{ width: "14em", marginRight: "160px" }}
                            >

                            </div>

                            <div
                                className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative"
                            >
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id='zt90' style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZT90
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zt90_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zt90_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zt90_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zt90_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zt90_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt90_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zt90_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zt90_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zt90_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zt90_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt90_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zt90_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zt90_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zt90_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zt90_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt90_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zt90_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zt90_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zt90_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zt90_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>


                            <div className="main  py-1 px-1 bg-dark d-flex flex-column  border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zt91" style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZT91
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex ">
                                    <div id="zt91_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zt91_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zt91_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zt91_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zt91_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zt91_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zt91_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zt91_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zt91_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zt91_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zt91_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zt91_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zt91_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zt91_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zt91_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex ">
                                    <div id="zt91_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zt91_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zt91_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zt91_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zt91_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>

                            <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zt92" style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZT92
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zt92_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zt92_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zt92_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zt92_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zt92_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt92_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zt92_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zt92_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zt92_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zt92_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt92_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zt92_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zt92_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zt92_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zt92_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zt92_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zt92_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zt92_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zt92_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zt92_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>


                            <div className=" bg-light" style={{ height: "20vh", width: "20em", marginRight: "160px" }} ></div>

                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zv90"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZV90
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zv90_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zv90_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zv90_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zv90_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zv90_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv90_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zv90_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zv90_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zv90_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zv90_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv90_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zv90_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zv90_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zv90_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zv90_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv90_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zv90_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zv90_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zv90_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zv90_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>


                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zv91"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZV91
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zv91_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zv91_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zv91_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zv91_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zv91_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv91_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zv91_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zv91_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zv91_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zv91_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv91_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zv91_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zv91_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zv91_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zv91_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv91_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zv91_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zv91_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zv91_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zv91_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>
                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zv92"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZV92
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zv92_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zv92_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zv92_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zv92_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zv92_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv92_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zv92_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zv92_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zv92_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zv92_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv92_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zv92_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zv92_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zv92_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zv92_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zv92_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zv92_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zv92_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zv92_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zv92_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>

                            <div className=" bg-light" style={{ height: "20vh", width: "20em", marginRight: "180px" }} ></div>

                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zx90"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZX90
                                </span>

                                {/* Static content for each row */}
                                <div className="d-flex">
                                    <div id="zx90_1" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>1</div>
                                    <div id="zx90_2" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>2</div>
                                    <div id="zx90_3" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>3</div>
                                    <div id="zx90_4" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>4</div>
                                    <div id="zx90_5" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>5</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zx90_6" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>6</div>
                                    <div id="zx90_7" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>7</div>
                                    <div id="zx90_8" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>8</div>
                                    <div id="zx90_9" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>9</div>
                                    <div id="zx90_10" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>10</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zx90_11" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>11</div>
                                    <div id="zx90_12" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>12</div>
                                    <div id="zx90_13" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>13</div>
                                    <div id="zx90_14" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>14</div>
                                    <div id="zx90_15" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>15</div>
                                </div>

                                <div className="d-flex">
                                    <div id="zx90_16" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>16</div>
                                    <div id="zx90_17" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>17</div>
                                    <div id="zx90_18" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>18</div>
                                    <div id="zx90_19" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>19</div>
                                    <div id="zx90_20" className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px', fontSize: "10px" }}>20</div>
                                </div>
                            </div>


                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zx91"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZX91
                                </span>

                                {/* Static content for each row */}
                                {[...Array(4)].map((_, rowIndex) => (
                                    <div key={rowIndex} className="d-flex">
                                        {[...Array(5)].map((_, colIndex) => (
                                            <div
                                                key={colIndex}
                                                id={`zx91_${rowIndex * 5 + colIndex + 1}`}
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: '5vh', width: '30px', fontSize: '10px' }}
                                            >
                                                {rowIndex * 5 + colIndex + 1}
                                            </div>
                                        ))}
                                    </div>
                                ))}
                            </div>

                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="zx92"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZX92
                                </span>

                                {/* Static content for each row */}
                                {[...Array(4)].map((_, rowIndex) => (
                                    <div key={rowIndex} className="d-flex">
                                        {[...Array(5)].map((_, colIndex) => (
                                            <div
                                                key={colIndex}
                                                id={`zx92_${rowIndex * 5 + colIndex + 1}`}
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: '5vh', width: '30px', fontSize: '10px' }}
                                            >
                                                {rowIndex * 5 + colIndex + 1}
                                            </div>
                                        ))}
                                    </div>
                                ))}
                            </div>

                            <div className=" bg-light" style={{ height: "20vh", width: "20em", marginRight: "180px" }} ></div>

                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id='zz90'
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZZ90
                                </span>

                                {/* Static content for each row */}
                                {[...Array(4)].map((_, rowIndex) => (
                                    <div className="d-flex" key={rowIndex}>
                                        {[...Array(5)].map((_, colIndex) => {
                                            const boxNumber = rowIndex * 5 + colIndex + 1;
                                            return (
                                                <div
                                                    key={boxNumber}
                                                    id={`zz90_${boxNumber}`}
                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                    style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                >
                                                    {boxNumber}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>


                            <div className="main bg-dark py-1 px-1 d-flex flex-column border-light border border-2 position-relative">
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id='zz91'
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    ZZ91
                                </span>

                                {/* Static content for each row */}
                                {[...Array(4)].map((_, rowIndex) => (
                                    <div className="d-flex" key={rowIndex}>
                                        {[...Array(5)].map((_, colIndex) => {
                                            const boxNumber = rowIndex * 5 + colIndex + 1;
                                            return (
                                                <div
                                                    key={boxNumber}
                                                    id={`zz91_${boxNumber}`}
                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                    style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                >
                                                    {boxNumber}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>



                        </div>
                        <div className="d-flex flex-row">
                            {/* First Column */}
                            <div className="d-flex flex-column">
                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s07"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S07
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s07_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s06"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S06
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s06_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s05"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S05
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s05_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s04"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S04
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s04_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s03"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S03
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s03_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s02"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S02
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s02_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>


                                <div className="main ms-4 py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="s01"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S01
                                    </span>

                                    {/* Static content for each row */}
                                    {[...Array(5)].map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {[...Array(4)].map((_, colIndex) => {
                                                const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                return (
                                                    <div
                                                        key={boxNumber}
                                                        id={`s01_${boxNumber}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                    >
                                                        {boxNumber}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>


                            </div>
                            {/* Second Column */}
                            <div className="d-flex">
                                <div className="ms-5 bg-light"></div>
                                <div className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                    >
                                        S10
                                    </span>
                                </div>
                            </div>
                            {/* third Column */}
                            <div className="third_column">
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="t01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            T01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`t01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* Fourth Column */}
                            <div className="fourth_column">
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5 ">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="u01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            U01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`u01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* Five column */}
                            <div className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em", marginLeft: "-27px" }}>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    S11
                                </span>
                            </div>
                            {/* six column */}
                            <div className="six_column">
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="v01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            V01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`v01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* seven column */}
                            <div className="seven_column">
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W05                                </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="w01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            W01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`w01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* 8 column */}
                            <div className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "7em", marginLeft: "-27px" }}>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    S12
                                </span>
                            </div>
                            {/* 9 column */}
                            <div className="9_column">
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="x01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            X01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`x01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* 10 column */}
                            <div className="ten_column">
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y02
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="y01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Y01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`y01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* 11 column */}
                            <div className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "7em", marginLeft: "-27px" }}>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                >
                                    S13
                                </span>
                            </div>
                            {/* 12 column */}
                            <div className="12_column">
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z14"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z14
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z14_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z13"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z13
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z13_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z12"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z12
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z12_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z11"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z11
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z11_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z10"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z10
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z10_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z09"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z09
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z09_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                    <div className="main py-1 px-1 bg-light d-flex flex-column  border-light border border-2 position-relative" style={{ width: "130px", height: "160px", fontSize: "10px" }}
                                    >
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z08"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z08
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z08_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>


                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z07"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z07
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z07_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main py-1 px-1 d-flex flex-column border-light border border-2 position-relative"
                                        style={{ width: "120px", height: "160px", position: "relative", fontSize: "10px" }}
                                        id="z16"
                                    >
                                        <span
                                            className="position-absolute text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{
                                                top: "50%", // Center vertically
                                                left: "50%", // Center horizontally
                                                transform: "translate(-50%, -50%)", // Adjust alignment
                                                zIndex: 1,
                                                backdropFilter: "blur(1px)",
                                            }}
                                        >
                                            Z16
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex ms-5 bg-dark" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 2 + colIndex + 1; // Calculate box number
                                                    if (boxNumber > 20) return null; // Stop at 20
                                                    return (
                                                        <div
                                                            key={colIndex}
                                                            id={`z16_${boxNumber}`} // Unique ID for each box
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>


                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z06"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z06
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z06_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z05"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z05
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z05_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z04"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z04
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z04_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z03"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z03
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z03_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main py-1 px-1 d-flex flex-column border-light border border-2 position-relative"
                                        style={{ width: "120px", height: "160px", position: "relative", fontSize: "10px" }}
                                        id="z15"
                                    >
                                        <span
                                            className="position-absolute text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{
                                                top: "50%", // Center vertically
                                                left: "50%", // Center horizontally
                                                transform: "translate(-50%, -50%)", // Adjust alignment
                                                zIndex: 1,
                                                backdropFilter: "blur(1px)",
                                            }}
                                        >
                                            Z15
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex ms-5 bg-dark" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 2 + colIndex + 1; // Calculate box number
                                                    if (boxNumber > 20) return null; // Stop at 20
                                                    return (
                                                        <div
                                                            key={colIndex}
                                                            id={`z15_${boxNumber}`} // Unique ID for each box
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                </div>
                                <div className="d-flex">
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z02"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z02_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div className="main  py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative" style={{ width: "130px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            id="z01"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)', fontSize: "10px" }}
                                        >
                                            Z01
                                        </span>

                                        {/* Static content for each row */}
                                        {[...Array(5)].map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {[...Array(4)].map((_, colIndex) => {
                                                    const boxNumber = rowIndex * 4 + colIndex + 1; // Calculate box number
                                                    return (
                                                        <div
                                                            key={boxNumber}
                                                            id={`z01_${boxNumber}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: '5vh', width: '30px', fontSize: "10px" }}
                                                        >
                                                            {boxNumber}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                </div>
                            </div>


                        </div>
                        <div className="d-flex" style={{ fontSize: "10px" }}>
                            <div className="" style={{ marginLeft: "225px" }}></div>
                            <div className="position-relative bg-secondary mt-2" id='s19'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "150px" }}
                                >
                                    S19
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "310px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s20'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "50px" }}
                                >
                                    S20
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "270px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s21'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "60px" }}
                                >
                                    S21
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "270px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s22'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "50px" }}
                                >
                                    S22
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "280px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s23'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "80px" }}
                                >
                                    S23
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "275px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s24'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "60px" }}
                                >
                                    S24
                                </span>
                            </div>
                            <div className="" style={{ marginLeft: "275px" }}></div>
                            <div className="ms-5 position-relative bg-secondary mt-2" id='s25'>
                                <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    id="z04"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                >
                                    S25
                                </span>
                            </div>

                        </div>

                    </div >

                </div>
            </div>



        </>
    )
}
