import React, { useState } from "react";

export default function Mezzanine() {

    return (
        <div
            style={{
                width: "100%",
                height: "100vh",

                transformOrigin: "top right", // Maintain origin for scaling

            }}
            className="m-auto"
        >
            <iframe
                src="/MezzanineFloor"
                style={{
                    width: "100%",
                    height: "100%",
                    border: "1px solid gary",
                }}
                title="Map"
            ></iframe>
        </div>
    );
}



