import React, { useState, useEffect } from 'react'

export default function Mezzanine() {
    const [zoomLevel, setZoomLevel] = useState(0.2); // Default Zoomed Out (-0.2 from 1)

    // Zoom In Function
    const handleZoomIn = () => {
        if (zoomLevel < 5) {
            setZoomLevel(prev => prev + 0.2);
        }
    };

    // Zoom Out Function
    const handleZoomOut = () => {
        if (zoomLevel > 0.2) { // Prevents zooming out too much
            setZoomLevel(prev => prev - 0.2);
        }
    };
    // maps fill color
    useEffect(() => {
        const ids = ['zj90_1', 'zj90_2', 'zj90_3', 'zj90_8', 'zj90_13', 'zj90_18', 'zj90_19', 'zj90_20'
            , 'j01', 'k01', 'k03', 'm02', 'R01_1', 'R01_2', 'R01_3', 'R01_4', 'R01_5',
            'R01_6', 'R01_7', 'R01_8', 'R01_9', 'R01_10',
            'R01_11', 'R01_12', 'R01_13', 'R01_14', 'R01_15',
            'R01_16', 'R01_17', 'R01_18', 'R01_19', 'R01_20'
        ]; 
        ids.forEach(id => {
            const element = document.getElementById(id);
            console.log(id);
            console.log(element);
            if (element) {
                element.style.setProperty('background-color', '#8f51dd', 'important');

            }
        });
    }, []);
    return (
        <>
            <div className="m-auto vh-100 vw-100">
                <div className="d-flex gap-3 p-2 bg-light shadow position-fixed top-0 start-50 translate-middle-x rounded mt-2 z-3">
                    <button
                        onClick={handleZoomIn}
                        className="btn btn-success"
                    >
                        +
                    </button>
                    <button
                        onClick={handleZoomOut}
                        className="btn btn-danger"
                    >-
                    </button>
                </div>

                <div className="position-absolute top-0 start-0 w-100 h-100 bg-center"
                    style={{
                        backgroundSize: 'cover',
                        transform: `scale(${zoomLevel})`,
                        transformOrigin: 'center center',
                        transition: 'transform 0.3s ease-in-out',
                    }}>
                    <h1 className='text-center'>Mezzanine Ground Floor</h1>
                    <div className="mt-3 p-3">
                        <div className="row gap-0 flex-row ">
                            <table className='table'>
                                <tr>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zj90' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZJ90
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zj90_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zj90_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zj90_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zj90_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zj90_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj90_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zj90_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zj90_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zj90_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zj90_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj90_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zj90_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zj90_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zj90_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zj90_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj90_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zj90_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zj90_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zj90_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zj90_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>

                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zj91' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZJ91
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zj91_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zj91_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zj91_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zj91_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zj91_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj91_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zj91_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zj91_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zj91_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zj91_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj91_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zj91_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zj91_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zj91_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zj91_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj91_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zj91_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zj91_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zj91_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zj91_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zj92' style={{ fontSize: "10px" }}   >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZJ92
                                            </span>
                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zj92_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zj92_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zj92_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zj92_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zj92_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj92_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zj92_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zj92_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zj92_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zj92_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj92_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zj92_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zj92_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zj92_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zj92_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zj92_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zj92_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zj92_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zj92_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zj92_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className=" bg-light" style={{ height: "20vh", width: "40vh" }} ></div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zl90' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZL90
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zl90_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zl90_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zl90_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zl90_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zl90_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl90_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zl90_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zl90_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zl90_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zl90_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl90_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zl90_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zl90_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zl90_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zl90_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl90_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zl90_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zl90_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zl90_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zl90_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zl91' style={{ fontSize: "10px" }}   >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZL91
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zl91_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zl91_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zl91_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zl91_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zl91_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl91_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zl91_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zl91_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zl91_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zl91_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl91_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zl91_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zl91_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zl91_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zl91_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl91_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zl91_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zl91_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zl91_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zl91_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zl92' style={{ fontSize: "10px" }}   >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZL92
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zl92_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zl92_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zl92_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zl92_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zl92_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl92_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zl92_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zl92_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zl92_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zl92_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl92_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zl92_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zl92_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zl92_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zl92_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zl92_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zl92_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zl92_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zl92_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zl92_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className=" bg-light" style={{ height: "20vh", width: "40vh" }} ></div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zn90' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZN90
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zn90_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zn90_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zn90_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zn90_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zn90_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn90_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zn90_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zn90_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zn90_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zn90_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn90_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zn90_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zn90_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zn90_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zn90_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn90_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zn90_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zn90_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zn90_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zn90_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zn91' style={{ fontSize: "10px" }} >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZN91
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zn91_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zn91_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zn91_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zn91_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zn91_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn91_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zn91_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zn91_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zn91_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zn91_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn91_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zn91_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zn91_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zn91_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zn91_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn91_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zn91_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zn91_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zn91_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zn91_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>

                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zn92' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZN92
                                            </span>
                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zn92_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zn92_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zn92_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zn92_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zn92_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn92_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zn92_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zn92_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zn92_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zn92_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn92_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zn92_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zn92_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zn92_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zn92_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zn92_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zn92_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zn92_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zn92_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zn92_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>

                                        <div className="main p-2 d-flex flex-column bg-light border-light border-end border-2 "
                                            style={{ width: "200px" }} >



                                        </div>
                                    </td>
                                    <td>

                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zp90' style={{ fontSize: "10px" }}   >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZP90
                                            </span>
                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zp90_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zp90_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zp90_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zp90_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zp90_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp90_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zp90_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zp90_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zp90_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zp90_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp90_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zp90_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zp90_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zp90_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zp90_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp90_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zp90_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zp90_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zp90_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zp90_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>

                                        <div className="main p-2 d-flex flex-column bg-dark border-light border-end border-2 position-relative"
                                            id='zp91' style={{ fontSize: "10px" }}  >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                ZP91
                                            </span>

                                            {/* Static content for each row */}
                                            <div className="d-flex ">
                                                <div id='zp91_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>1</div>
                                                <div id='zp91_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>2</div>
                                                <div id='zp91_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>3</div>
                                                <div id='zp91_4' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>4</div>
                                                <div id='zp91_5' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>5</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp91_6' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>6</div>
                                                <div id='zp91_7' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>7</div>
                                                <div id='zp91_8' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>8</div>
                                                <div id='zp91_9' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>9</div>
                                                <div id='zp91_10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>10</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp91_11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>11</div>
                                                <div id='zp91_12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>12</div>
                                                <div id='zp91_13' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>13</div>
                                                <div id='zp91_14' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>14</div>
                                                <div id='zp91_15' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>15</div>
                                            </div>

                                            <div className="d-flex ">
                                                <div id='zp91_16' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>16</div>
                                                <div id='zp91_17' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>17</div>
                                                <div id='zp91_18' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>18</div>
                                                <div id='zp91_19' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>19</div>
                                                <div id='zp91_20' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ height: '5vh', width: '30px' }}>20</div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <div className="main_div d-flex">
                                <div className="d-flex flex-column">
                                    <div id='j01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J01
                                        </span>
                                    </div>
                                    <div id='j02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J02
                                        </span>
                                    </div>
                                    <div id='j03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J03
                                        </span>
                                    </div>
                                    <div id='j04' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J04
                                        </span>
                                    </div>
                                    <div id="j05" className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J05
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='j06' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J06
                                        </span>
                                        <div id='j06_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "130px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='j06_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "70px", height: "23vh" }}>
                                            2
                                        </div>
                                    </div>
                                    <div id='jo7' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J07
                                        </span>
                                        <div id='j07_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ width: "30px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='j07_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "40px", height: "23vh" }}>
                                            2
                                        </div>
                                        <div id='j03_3' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "130px", height: "23vh" }}>
                                            3
                                        </div>
                                    </div>
                                    <div id='j08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J08
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}></div>
                                    <div id='j09' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            J09
                                        </span>
                                        <div id='j09_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "130px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='j10' className=" position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "70px", height: "23vh" }}>
                                            <span
                                                className="position-absolute top-50 start-100 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                J10
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-2 bg-light" style={{ height: '23vh', width: "8em" }}></div>
                                <div className="d-flex flex-column">
                                    <div id='k01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K01
                                        </span>
                                    </div>
                                    <div id='k02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K02
                                        </span>
                                    </div>
                                    <div id='k03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K03
                                        </span>
                                    </div>
                                    <div id='k04' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K04
                                        </span>
                                    </div>
                                    <div id='k05' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K05
                                        </span>
                                    </div>
                                    <div id='k06' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K06
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='k07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K07
                                        </span>
                                    </div>
                                    <div id='k08' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K08
                                        </span>
                                        <div id='k08_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ width: "100px", height: "15vh" }}>
                                            1
                                        </div>
                                        <div id='k08_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "150px", height: "15vh" }}>
                                            2
                                        </div>

                                    </div>
                                    <div id='k09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "18vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K09
                                        </span>
                                    </div>
                                    <div className="col-md-2 bg-light" style={{ height: '15vh', width: "15em" }}></div>
                                    <div id='k10' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "18vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            K10
                                        </span>
                                    </div>
                                    <div className="d-flex position-relative">
                                        <div id='j10' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "100px", height: "23vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                J10
                                            </span>

                                            {/* 2 */}
                                        </div>
                                        <div id='k11' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "150px", height: "23vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                K11
                                            </span>

                                            {/* 2 */}
                                        </div>

                                    </div>
                                </div>
                                <div id="s6" className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "5em" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                    >
                                        S6
                                    </span>
                                </div>
                                <div className="d-flex flex-column">
                                    <div id='l01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L01
                                        </span>
                                    </div>
                                    <div id='l02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L02
                                        </span>
                                    </div>
                                    <div id='l03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L03
                                        </span>
                                    </div>
                                    <div id='l04' className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L04
                                        </span>
                                    </div>
                                    <div id='l05' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L05
                                        </span>
                                    </div>
                                    <div id='l06' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L06
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='l07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L07
                                        </span>
                                    </div>
                                    <div id='l08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L08
                                        </span>
                                    </div>
                                    <div id='l09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L09
                                        </span>
                                    </div>
                                    <div id='l10' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "200px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            L10
                                        </span>
                                    </div>
                                    <div className="d-flex">
                                        <div id='l11' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "150px", height: "23vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                L11
                                            </span>
                                        </div>
                                        <div id='m12' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "100px", height: "23vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                M12
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-2 bg-light border border-light rounded " style={{ height: '5vh', width: "7em" }}>

                                </div>
                                <div className="d-flex flex-column">
                                    <div id='m01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M01
                                        </span>
                                    </div>
                                    <div id='m02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M02
                                        </span>
                                    </div>
                                    <div id='m03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M03
                                        </span>
                                    </div>
                                    <div id='m04' className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M04
                                        </span>
                                    </div>
                                    <div id='m05' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M05
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='m07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M07
                                        </span>
                                    </div>
                                    <div id='m08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M08
                                        </span>
                                    </div>
                                    <div id='m09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M09
                                        </span>
                                    </div>
                                    <div id='m10' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M10
                                        </span>
                                    </div>
                                    <div id='m11' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M11
                                        </span>
                                    </div>
                                    <div className="d-flex">
                                        <div id='m12' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "80px", height: "21vh" }}>

                                        </div>
                                        <div id='m13' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "120px", height: "21vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                M13
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="">
                                    <div className="bg-light border border-light rounded position-relative" style={{ height: '46vh', width: "90px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            {/* S7 */}
                                        </span>
                                    </div>
                                    <div id='m06' className="bg-secondary border border-light rounded position-relative" style={{ height: '69vh', width: "90px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M06
                                        </span>
                                    </div>

                                </div>
                                <div id='s7' className=" col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "7em" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                    >
                                        S7
                                    </span>

                                </div>
                                <div className="col-md-1 bg-light" style={{ width: "20px" }}></div>
                                <div className="d-flex flex-column">
                                    <div id='n01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N01
                                        </span>
                                    </div>
                                    <div id='n02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N02
                                        </span>
                                    </div>
                                    <div id='n03' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N03
                                        </span>
                                        <div id='n03_1' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "10px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='n03_3' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "122px", height: "23vh" }}>
                                            3

                                        </div>
                                    </div>
                                    <div id='n04' className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N04
                                        </span>
                                    </div>
                                    <div id='n05' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N05
                                        </span>
                                        <div id='n05_1' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "122px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='n05_3' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "10px", height: "23vh" }}>
                                            3

                                        </div>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='n06' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "22vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N06
                                        </span>
                                    </div>
                                    <div id='n07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "22vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N07
                                        </span>
                                    </div>
                                    <div id="n08" className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N08
                                        </span>
                                        <div id='n08_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "110px", height: "19vh" }}>
                                            1
                                        </div>
                                        <div id='n08_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "110px", height: "19vh" }}>
                                            2
                                        </div>

                                    </div>
                                    <div id='n07' className="bg-light border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "18vh" }}>
                                        {/* <span
                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                >
                                    N07
                                </span> */}
                                    </div>
                                    <div className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            N09
                                        </span>
                                        <div id='n09_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "80px", height: "25vh" }}>
                                            1
                                        </div>
                                        <div id='n09_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center " style={{ width: "80px", height: "25vh" }}>
                                            2
                                        </div>
                                        <div id='n10' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ width: "60px", height: "25vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                N10
                                            </span>
                                        </div>

                                    </div>
                                </div>
                                <div className="bg-light border border-light rounded position-relative p-5" style={{ height: '5vh', width: "6em" }}>
                                </div>
                                <div className="d-flex flex-column">
                                    <div id='o01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O01
                                        </span>
                                    </div>
                                    <div id='o02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O02
                                        </span>
                                    </div>
                                    <div id='o03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O03
                                        </span>
                                    </div>
                                    <div className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O04
                                        </span>
                                    </div>
                                    <div id='o05' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O05
                                        </span>
                                    </div>
                                    <div id='o06' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O06
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='o07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "18vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O07
                                        </span>
                                    </div>
                                    <div id='o08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "18vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O08
                                        </span>
                                    </div>
                                    <div id='o09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "18vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O09
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "12vh" }}>
                                    </div>
                                    <div id='o10' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O10
                                        </span>
                                        <div id='o10_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "150px", height: "15vh" }}>
                                            1
                                        </div>
                                        <div id='o10_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "50px", height: "15vh" }}>
                                            2
                                        </div>

                                    </div>
                                    <div id='o11' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            O11
                                        </span>
                                        <div id='o11_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "50px", height: "25vh" }}>
                                            1
                                        </div>
                                        <div id='o11_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "150px", height: "25vh" }}>
                                            2
                                        </div>

                                    </div>
                                </div>
                                <div id='s8' className=" col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "7em" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                    >
                                        S8
                                    </span>

                                </div>
                                <div className="d-flex flex-column">
                                    <div id='p01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P01
                                        </span>
                                    </div>
                                    <div id='p02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P02
                                        </span>
                                    </div>
                                    <div id='p03' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P03
                                        </span>
                                    </div>
                                    <div id='p04' className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P04
                                        </span>
                                    </div>
                                    <div className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P05
                                        </span>
                                    </div>
                                    <div id='p06' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P06
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='p07' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P07
                                        </span>
                                        <div id='p07_1' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "125px", height: "18vh" }}>
                                            1
                                        </div>
                                        <div id='p07_2' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "125px", height: "18vh" }}>
                                            2
                                        </div>
                                    </div>
                                    <div id='p08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "19vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P08
                                        </span>
                                    </div>
                                    <div id='p09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "250px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P09
                                        </span>
                                    </div>
                                    <div id='p10' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "210px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            P10
                                        </span>
                                    </div>
                                    <div className="d-flex">
                                        <div id='p11' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "150px", height: "25vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                P11
                                            </span>
                                        </div>
                                        <div id='p12' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "100px", height: "25vh" }}>

                                        </div>
                                    </div>
                                </div>
                                <div className="bg-light border border-light rounded position-relative p-5" style={{ height: '5vh', width: "10px" }}>
                                </div>
                                <div className="d-flex flex-column">
                                    <div id='q01' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q01
                                        </span>
                                    </div>
                                    <div id='q02' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q02
                                        </span>
                                    </div>
                                    <div id='q03' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q03
                                        </span>
                                        <div id='q03_1' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ width: "50px", height: "23vh" }}>
                                            1
                                        </div>
                                        <div id='q03_2' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center" style={{ width: "50px", height: "23vh" }}>
                                            2
                                        </div>
                                        <div id='q03_3' className=" bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "120px", height: "23vh" }}>
                                            3
                                        </div>
                                    </div>
                                    <div id='q04' className="position-relative bg-secondary border rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q04
                                        </span>
                                    </div>
                                    <div id='q05' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "23vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q05
                                        </span>
                                    </div>
                                    <div className=" bg-light" style={{ width: "210px", height: "15vh" }}>
                                    </div>
                                    <div id='q07' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q07
                                        </span>
                                    </div>
                                    <div id='q08' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q08
                                        </span>
                                    </div>
                                    <div id='q09' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q09
                                        </span>
                                    </div>
                                    <div id='q10' className="d-flex position-relative">
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q10
                                        </span>
                                        <div id='q10_1' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "110px", height: "19vh" }}>
                                            1
                                        </div>
                                        <div id='q10_2' className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "110px", height: "19vh" }}>
                                            2
                                        </div>
                                    </div>
                                    <div id='q11' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "220px", height: "16vh" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            Q11
                                        </span>
                                    </div>
                                    <div className="d-flex">
                                        <div id='p12' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "80px", height: "21vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                P12
                                            </span>
                                        </div>
                                        <div id='q12' className="position-relative bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center p-5" style={{ width: "120px", height: "21vh" }}>
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                            >
                                                Q12
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="">
                                    <div className="bg-light border border-light rounded position-relative" style={{ height: '46vh', width: "90px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            {/* S7 */}
                                        </span>
                                    </div>
                                    <div id='m06' className="bg-secondary border border-light rounded position-relative" style={{ height: '69vh', width: "90px" }}>
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                            style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                        >
                                            M06
                                        </span>
                                    </div>

                                </div>
                                <div id='s9' className=" col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "7em" }}>
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                    >
                                        S9
                                    </span>

                                </div>
                                <div className="col-md-1 bg-light" style={{ width: "20px" }}></div>
                                <div className="right_sec">
                                    <div className="d-flex gap-0 flex-row m-auto">
                                        {['R01', 'R02', 'R03', 'R04'].map((rowLabel) => (
                                            <div
                                                key={rowLabel}
                                                id={rowLabel} // Main box ID
                                                className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            >
                                                <span
                                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                                >
                                                    {rowLabel}
                                                </span>
                                                {[...Array(4)].map((_, rowIndex) => (
                                                    <div key={rowIndex} className="d-flex">
                                                        {[...Array(5)].map((_, colIndex) => {
                                                            const boxNumber = rowIndex * 5 + colIndex + 1; // Calculate box number
                                                            const boxId = `${rowLabel}_${boxNumber}`; // Generate unique ID
                                                            return (
                                                                <div
                                                                    key={boxId}
                                                                    id={boxId} // Assign unique ID to each inner box
                                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                    style={{ height: '11vh', width: '20px', fontSize: '10px' }}
                                                                >
                                                                    {boxNumber}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                ))}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="bg-light border border-light rounded position-relative " style={{ height: '20vh', width: "10px" }}>
                                    </div>
                                    <div className="d-flex gap-0 flex-row m-auto">
                                        {['R05', 'R06', 'R07', 'R08'].map((rowLabel) => (
                                            <div
                                                key={rowLabel}
                                                id={rowLabel} // Main box ID
                                                className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            >
                                                <span
                                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                                >
                                                    {rowLabel}
                                                </span>
                                                {[...Array(4)].map((_, rowIndex) => (
                                                    <div key={rowIndex} className="d-flex">
                                                        {[...Array(5)].map((_, colIndex) => {
                                                            const boxNumber = rowIndex * 5 + colIndex + 1; // Calculate box number
                                                            const boxId = `${rowLabel}_${boxNumber}`; // Generate unique ID
                                                            return (
                                                                <div
                                                                    key={boxId}
                                                                    id={boxId} // Assign unique ID to each inner box
                                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                    style={{ height: '11vh', width: '20px', fontSize: '10px' }}
                                                                >
                                                                    {boxNumber}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                ))}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex gap-0 flex-row m-auto">
                                        {['R09', 'R10', 'R11', 'R12'].map((rowLabel) => (
                                            <div
                                                key={rowLabel}
                                                id={rowLabel} // Main box ID
                                                className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            >
                                                <span
                                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                                >
                                                    {rowLabel}
                                                </span>
                                                {[...Array(4)].map((_, rowIndex) => (
                                                    <div key={rowIndex} className="d-flex">
                                                        {[...Array(5)].map((_, colIndex) => {
                                                            const boxNumber = rowIndex * 5 + colIndex + 1; // Calculate box number
                                                            const boxId = `${rowLabel}_${boxNumber}`; // Generate unique ID
                                                            return (
                                                                <div
                                                                    key={boxId}
                                                                    id={boxId} // Assign unique ID to each inner box
                                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                    style={{ height: '11vh', width: '20px', fontSize: '10px' }}
                                                                >
                                                                    {boxNumber}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                ))}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="bg-light border border-light rounded position-relative " style={{ height: '25vh', width: "10px" }}>
                                    </div>
                                    <div className="d-flex gap-0 flex-row m-auto">
                                        {['R13', 'R14', 'R15', 'R16'].map((rowLabel) => (
                                            <div
                                                key={rowLabel}
                                                id={rowLabel} // Main box ID
                                                className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            >
                                                <span
                                                    className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                    style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                                                >
                                                    {rowLabel}
                                                </span>
                                                {[...Array(4)].map((_, rowIndex) => (
                                                    <div key={rowIndex} className="d-flex">
                                                        {[...Array(5)].map((_, colIndex) => {
                                                            const boxNumber = rowIndex * 5 + colIndex + 1; // Calculate box number
                                                            const boxId = `${rowLabel}_${boxNumber}`; // Generate unique ID
                                                            return (
                                                                <div
                                                                    key={boxId}
                                                                    id={boxId} // Assign unique ID to each inner box
                                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                    style={{ height: '11vh', width: '20px', fontSize: '10px' }}
                                                                >
                                                                    {boxNumber}
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                ))}
                                            </div>
                                        ))}
                                    </div>

                                </div>
                            </div>
                            <div className="end_section d-flex mt-3">
                                <div className="" style={{ marginRight: "260px" }}></div>
                                <div id='s10' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "150px" }}
                                    >
                                        S10
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "220px" }}></div>
                                <div id='s11' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S11
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "250px" }}></div>
                                <div id='s12' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S12
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "250px" }}></div>
                                <div id='s13' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S13
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "330px" }}></div>
                                <div id='s14' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S14
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "270px" }}></div>
                                <div id='s15' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S15
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "270px" }}></div>
                                <div id='s16' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S16
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "270px" }}></div>
                                <div id='s17' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S17
                                    </span>
                                </div>
                                <div className="" style={{ marginRight: "430px" }}></div>
                                <div id='s18' className="border border-light rounded text-white d-flex ">
                                    <span
                                        className=" translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: 'blur(1px)', width: "90px" }}
                                    >
                                        S18
                                    </span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </>

    )
}
