import React, { useState, useEffect } from 'react'

export default function Map() {
    const [zoomLevel, setZoomLevel] = useState(0.4); // Default Zoomed Out (-0.2 from 1)

    // Zoom In Function
    const handleZoomIn = () => {
        if (zoomLevel < 5) {
            setZoomLevel(prev => prev + 0.2);
        }
    };

    // Zoom Out Function
    const handleZoomOut = () => {
        if (zoomLevel > 0.2) { // Prevents zooming out too much
            setZoomLevel(prev => prev - 0.2);
        }
    };
    // maps fill color
    useEffect(() => {
        const ids = ['a01_1', 'a01_2', 'a01_3', 'a01_4', 'a28_1', 'a28_3', 'a28_4', 'a28_2', 'a27_2', 'a27_1'];
        ids.forEach(id => {
            const element = document.getElementById(id);
            console.log(id);
            console.log(element);
            if (element) {
                element.style.setProperty('background-color', '#8f51dd', 'important');
            }
        });
    }, []);
    return (
        <>
            <div className="container mt-4">
                <div className="d-flex gap-3 p-2 bg-light shadow position-fixed top-0 start-50 translate-middle-x rounded mt-2 z-3">
                    <button
                        onClick={handleZoomIn}
                        className="btn btn-success"
                    >
                        +
                    </button>
                    <button
                        onClick={handleZoomOut}
                        className="btn btn-danger"
                    >
                        -
                    </button>
                </div>
                <div className="position-absolute top-0 start-0 w-100 h-100 bg-center"
                    style={{
                        backgroundSize: 'cover',
                        transform: `scale(${zoomLevel})`,
                        transformOrigin: 'center center',
                        transition: 'transform 0.3s ease-in-out',
                    }}>
                    <h1 className='text-center'>LCL Workshop Ground Floor</h1>
                    <div className="row bg-light border border-dark">
                        <div className="col-md-2">
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a01">A01</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a01_1">1</div>
                                        <div className="small-box" id="a01_3">3</div>
                                        <div className="small-box" id="a01_2">2</div>
                                        <div className="small-box" id="a01_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a02">A02</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a02_1">1</div>
                                        <div className="small-box" id="a02_3">3</div>
                                        <div className="small-box" id="a02_2">2</div>
                                        <div className="small-box" id="a02_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a03">A03</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a03_1">1</div>
                                        <div className="small-box" id="a03_3">3</div>
                                        <div className="small-box" id="a03_2">2</div>
                                        <div className="small-box" id="a03_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a04">A04</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a04_1">1</div>
                                        <div className="small-box" id="a04_3">3</div>
                                        <div className="small-box" id="a04_2">2</div>
                                        <div className="small-box" id="a04_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a05">A05</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a05_1">1</div>
                                        <div className="small-box" id="a05_3">3</div>
                                        <div className="small-box" id="a05_2">2</div>
                                        <div className="small-box" id="a05_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a06">A06</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a06_1">1</div>
                                        <div className="small-box" id="a06_3">3</div>
                                        <div className="small-box" id="a06_2">2</div>
                                        <div className="small-box" id="a06_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a07">A07</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a07_1">1</div>
                                        <div className="small-box" id="a07_3">3</div>
                                        <div className="small-box" id="a07_2">2</div>
                                        <div className="small-box" id="a07_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a08">A08</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a08_1">1</div>
                                        <div className="small-box" id="a08_3">3</div>
                                        <div className="small-box" id="a08_2">2</div>
                                        <div className="small-box" id="a08_4">4</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-1"></div>
                        <div className="col-md-4">
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a09">A09</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a09_3">3</div>
                                            <div className="small-box" id="a09_1">1</div>
                                            <div className="small-box" id="a09_4">4</div>
                                            <div className="small-box" id="a09_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a10">A10</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a10_3">3</div>
                                            <div className="small-box" id="a10_1">1</div>
                                            <div className="small-box" id="a10_4">4</div>
                                            <div className="small-box" id="a10_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a11">A11</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a11_3">3</div>
                                            <div className="small-box" id="a11_1">1</div>
                                            <div className="small-box" id="a11_4">4</div>
                                            <div className="small-box" id="a01_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a12">A12</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a12_3">3</div>
                                            <div className="small-box" id="a12_1">1</div>
                                            <div className="small-box" id="a12_4">4</div>
                                            <div className="small-box" id="a12_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a13">A13</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a13_3">3</div>
                                            <div className="small-box" id="a13_1">1</div>
                                            <div className="small-box" id="a13_4">4</div>
                                            <div className="small-box" id="a13_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a14">A14</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a14_3">3</div>
                                            <div className="small-box" id="a14_1">1</div>
                                            <div className="small-box" id="a14_4">4</div>
                                            <div className="small-box" id="a14_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a15">A15</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a15_3">3</div>
                                            <div className="small-box" id="a15_1">1</div>
                                            <div className="small-box" id="a15_4">4</div>
                                            <div className="small-box" id="a15_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a16">A16</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a16_3">3</div>
                                            <div className="small-box" id="a16_1">1</div>
                                            <div className="small-box" id="a16_4">4</div>
                                            <div className="small-box" id="a16_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-light">


                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-light">


                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a28">A28</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a28_3">3</div>
                                            <div className="small-box" id="a28_1">1</div>
                                            <div className="small-box" id="a28_4">4</div>
                                            <div className="small-box" id="a28_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a29">A29</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a29_3">3</div>
                                            <div className="small-box" id="a29_1">1</div>
                                            <div className="small-box" id="a29_4">4</div>
                                            <div className="small-box" id="a29_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a30">A30</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a30_3">3</div>
                                            <div className="small-box" id="a30_1">1</div>
                                            <div className="small-box" id="a30_4">4</div>
                                            <div className="small-box" id="a30_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a31">A31</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a31_3">3</div>
                                            <div className="small-box" id="a31_1">1</div>
                                            <div className="small-box" id="a31_4">4</div>
                                            <div className="small-box" id="a31_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a32">A32</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a32_3">3</div>
                                            <div className="small-box" id="a32_1">1</div>
                                            <div className="small-box" id="a32_4">4</div>
                                            <div className="small-box" id="a32_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a33">A33</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a33_3">3</div>
                                            <div className="small-box" id="a33_1">1</div>
                                            <div className="small-box" id="a33_4">4</div>
                                            <div className="small-box" id="a33_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a34">A34</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a32_3">3</div>
                                            <div className="small-box" id="a32_1">1</div>
                                            <div className="small-box" id="a32_4">4</div>
                                            <div className="small-box" id="a32_2">2</div>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a35">A35</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a35_3">3</div>
                                            <div className="small-box" id="a35_1">1</div>
                                            <div className="small-box" id="a35_4">4</div>
                                            <div className="small-box" id="a35_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a36">A36</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a36_2">2</div>
                                            <div className="small-box" id="a36_1">1</div>
                                            <div className="small-box bg-light" id="a36_3">3</div>
                                            <div className="small-box bg-light" id="a36_4">4</div>

                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a37">A37</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a37_3">3</div>
                                            <div className="small-box" id="a37_1">1</div>
                                            <div className="small-box" id="a37_4">4</div>
                                            <div className="small-box" id="a37_2">2</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main">
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    {/* <div className="text-white bg-dark" style={{width:"100%" , height:"100%", borderRadius:"5px"}}>
                                    <span  className="position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
    style={{
        fontSize: "16px",
        textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
        background: "rgb(0 0 0 / 66%)",
        boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
    }} id="a36">A36</span>
                                    <div className="d-grid position-absolute"
    style={{
        gridTemplateColumns: "repeat(2, 1fr)",
        gap: "2px",
        bottom: "5px",
        left: "5px",
        right: "5px"
    }}>
                                        <div className="small-box" id="a36_2">2</div>
                                        <div className="small-box" id="a36_1">1</div>
                                        <div className="small-box bg-light" id="a36_3">3</div>
                                        <div className="small-box bg-light" id="a36_4">4</div>

                                    </div>
                                </div> */}
                                </div>
                                <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                    <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                        <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                            style={{
                                                fontSize: "16px",
                                                textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                                background: "rgb(0 0 0 / 66%)",
                                                boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                            }} id="a37">A38</span>
                                        <div className="d-grid position-absolute"
                                            style={{
                                                gridTemplateColumns: "repeat(2, 1fr)",
                                                gap: "2px",
                                                bottom: "5px",
                                                left: "5px",
                                                right: "5px"
                                            }}>
                                            <div className="small-box" id="a37_4">4</div>
                                            <div className="small-box" id="a37_2">2</div>
                                            <div className="small-box bg-light" id="a37_3">3</div>
                                            <div className="small-box bg-light" id="a37_1">1</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div className="col-md-1"></div>
                        <div className="col-md-4">
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a17">A17</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a17_3">3</div>
                                        <div className="small-box" id="a17_1">1</div>
                                        <div className="small-box" id="a17_4">4</div>
                                        <div className="small-box" id="a17_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a18">A18</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a18_3">3</div>
                                        <div className="small-box" id="a18_1">1</div>
                                        <div className="small-box" id="a18_4">4</div>
                                        <div className="small-box" id="a18_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a19">A19</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a19_3">3</div>
                                        <div className="small-box" id="a19_1">1</div>
                                        <div className="small-box" id="a19_4">4</div>
                                        <div className="small-box" id="a19_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a20">A20</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a20_3">3</div>
                                        <div className="small-box" id="a20_1">1</div>
                                        <div className="small-box" id="a20_4">4</div>
                                        <div className="small-box" id="a20_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a21">A21</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a21_3">3</div>
                                        <div className="small-box" id="a21_1">1</div>
                                        <div className="small-box" id="a21_4">4</div>
                                        <div className="small-box" id="a21_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a22">A22</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a22_3">3</div>
                                        <div className="small-box" id="a22_1">1</div>
                                        <div className="small-box" id="a22_4">4</div>
                                        <div className="small-box" id="a22_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a23">A23</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a23_3">3</div>
                                        <div className="small-box" id="a23_1">1</div>
                                        <div className="small-box" id="a23_4">4</div>
                                        <div className="small-box" id="a23_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a24">A24</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a24_1">1</div>
                                        <div className="small-box" id="a24_3">3</div>
                                        <div className="small-box" id="a24_2">2</div>
                                        <div className="small-box" id="a24_4">4</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a25">A25</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a24_3">3</div>
                                        <div className="small-box" id="a24_1">1</div>
                                        <div className="small-box" id="a24_4">4</div>
                                        <div className="small-box" id="a24_1">1</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a26">A26</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a26_3">3</div>
                                        <div className="small-box" id="a26_1">1</div>
                                        <div className="small-box" id="a26_4">4</div>
                                        <div className="small-box" id="a26_2">2</div>
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-center align-items-center position-relative" style={{ width: "175px", height: "92px" }} >
                                <div className="text-white bg-dark" style={{ width: "100%", height: "100%", borderRadius: "5px" }}>
                                    <span className="z-3 position-absolute top-50 start-50 translate-middle fw-bold text-white text-center px-2 py-1 rounded"
                                        style={{
                                            fontSize: "16px",
                                            textShadow: "1px 1px 2px rgba(0, 0, 0, 0.7)",
                                            background: "rgb(0 0 0 / 66%)",
                                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.3)"
                                        }} id="a27">A27</span>
                                    <div className="d-grid position-absolute"
                                        style={{
                                            gridTemplateColumns: "repeat(2, 1fr)",
                                            gap: "2px",
                                            bottom: "5px",
                                            left: "5px",
                                            right: "5px"
                                        }}>
                                        <div className="small-box" id="a27_2">2</div>
                                        <div className="small-box" id="a27_1">1</div>
                                        <div className="small-box bg-light" id="a02_2"></div>
                                        <div className="small-box bg-light" id="a02_4"></div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-2">
                            <div className="card bg-secondary text-light">
                                <div className=" fs-5 text-center">
                                    <strong>S1</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div >
            </div>
        </>
    )
}
