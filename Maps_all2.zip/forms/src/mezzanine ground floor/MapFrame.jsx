import React, { useState } from "react";

export default function MapFrame() {

    return (
        <div
            style={{
                width: "100%",
                height: "100vh",

                transformOrigin: "top right", // Maintain origin for scaling

            }}
            className="m-auto"
        >
            <iframe
                src="/Map"
                style={{
                    width: "100%",
                    height: "100%",
                    border: "1px solid gary",
                }}
                title="Map"
            ></iframe>
        </div>
    );
}



