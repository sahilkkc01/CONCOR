import React, { useState } from "react";

export default function OldLclFrame() {

    return (
        <div
            style={{
                width: "100%",
                height: "100vh",

                transformOrigin: "top right", // Maintain origin for scaling

            }}
            className="m-auto"
        >
            <iframe
                src="/OldLcl"
                style={{
                    width: "100%",
                    height: "100%",
                    border: "1px solid gary",
                }}
                title="Map"
            ></iframe>
        </div>
    );
}



