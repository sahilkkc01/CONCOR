import React, { forwardRef, useState , useEffect  } from 'react'

export default function OldLcl() {
    const [zoomLevel, setZoomLevel] = useState(0.1); // Default Zoomed Out (-0.2 from 1)

    // Zoom In Function
    const handleZoomIn = () => {
        if (zoomLevel < 5) {
            setZoomLevel(prev => prev + 0.2);
        }
    };

    // Zoom Out Function
    const handleZoomOut = () => {
        if (zoomLevel > 0.2) { // Prevents zooming out too much
            setZoomLevel(prev => prev - 0.2);
        }
    };
    // maps fill color
    useEffect(() => {
        const ids = ['c01_1', 'c01_2', 'c01_3', 'c01_8', 'c01_13', 'c01_18', 'c01_19', 'c01_20']; // IDs list
        ids.forEach(id => {
            const element = document.getElementById(id);
            console.log(id);
            console.log(element);
            if (element) {
                element.style.setProperty('background-color', '#8f51dd', 'important');

            }
        });
    }, []);
    return (
        <>
            <div className="m-auto vh-100 vw-100">
                <div className="d-flex gap-3 p-2 bg-light shadow position-fixed top-0 start-50 translate-middle-x rounded mt-2 z-3">
                    <button
                        onClick={handleZoomIn}
                        className="btn btn-success"
                    >
                        +
                    </button>
                    <button
                        onClick={handleZoomOut}
                        className="btn btn-danger"
                    >
                        -
                    </button>
                </div>

                <div className="position-absolute top-0 start-0 w-100 h-100 bg-center"
                    style={{
                        backgroundSize: 'cover',
                        transform: `scale(${zoomLevel})`,
                        transformOrigin: 'center center',
                        transition: 'transform 0.3s ease-in-out',
                    }}>
                    <h1 className='text-center'>Old Lcl Warehouse</h1>
                    <div className="Lcl p-3 m-5">
                        <div className="d-flex">
                            {/* A01 , A02 , B01 , B02 */}
                            <div className="d-flex flex-column">
                                <div className="main bg-light" style={{ width: "556px", height: "5vh" }}></div>
                                <div className="main bg-light" style={{ width: "400px", height: "159vh" }}></div>
                                <div className="main bg-light" style={{ width: "556px", height: "5vh" }}></div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='a01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            A01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 4 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 5 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 5 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`a01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='a02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            A02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 4 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 5 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 5 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`a02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='b01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            B01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 4 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 5 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 5 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`b01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='b02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            B02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 4 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 5 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 5 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`b02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* C01 to C09 */}
                            <div className="d-flex flex-column">
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='c01'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        C01
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c01_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='c02'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        C02
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c02_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='c03'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        C03
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c03_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }}
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }} id='c04'
                                    >
                                        C04
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c04_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='c08'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        C08
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c08_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='c09'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        C09
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`c09_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="bg-light p-4"></div>
                            {/* D01 to D11 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='d08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}
                                    <div
                                        className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="d09"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            D09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`d09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='d10'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                D10
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`d10_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='d11'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                D11
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`d11_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                            </div>
                            {/* E01 to E12 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='e12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            E12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* F01 to F12 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4 me-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`e11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='f12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            F12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`f12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* G1 to G12  */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='g12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            G12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`g12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            <div className="bg-light p-5"></div>
                            {/* H01 to H11 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='h08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}
                                    <div
                                        className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="h09"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            H09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`h09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='h10'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                H10
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`h10_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='h11'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                H11
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`h11_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>


                            </div>
                            {/* I1 to I12 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='i12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            I12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`i12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* J01 to J10 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}


                                    <div className="d-flex ms-5 flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='j01'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                J01
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`j01_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='j03'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                J03
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`j03_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div
                                        className="main  p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="j02"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}


                                    <div className="d-flex ms-5 flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='j04'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                J04
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`j04_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='j06'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                J06
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`j06_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div
                                        className="main  p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="j05"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>


                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='j07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='j08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4 me-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='j09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='j12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            J12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`j12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* K01 to K09 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}
                                    <div
                                        className="main ms-3 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="k01"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            K01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`k01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='k02'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K02
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`k02_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='k03'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K03
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`k03_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex">
                                    {/* 1 row me 2 box */}
                                    <div
                                        className="main ms-3 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="k04"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            K04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`k04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='k05'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K05
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`k05_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='k06'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K06
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`ko6_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-3">
                                    {/* 1 row me 2 box */}
                                    <div
                                        className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="k07"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            K07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`k07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="d-flex flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='k08'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K08
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`k08_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id=''
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                K09
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* L01 to L12 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-3">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-3">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-3">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-3">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='l12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            L12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`l12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* M01 to M11 */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='m08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-3">
                                    {/* 1 row me 2 box */}


                                    <div className="d-flex ms-5 flex-column">
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='m09'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                M09
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`m09_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                        <div
                                            className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                            style={{ fontSize: "10px", width: "140px" }} id='m11'
                                        >
                                            <span
                                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                            >
                                                M11
                                            </span>

                                            {/* Dynamic Rows and Boxes */}
                                            {Array.from({ length: 5 }).map((_, rowIndex) => (
                                                <div className="d-flex" key={rowIndex}>
                                                    {Array.from({ length: 4 }).map((_, colIndex) => {
                                                        const boxId = rowIndex * 4 + colIndex + 1;
                                                        return (
                                                            <div
                                                                key={boxId}
                                                                id={`m11_${boxId}`}
                                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                                style={{ height: "5vh", width: "30px" }}
                                                            >
                                                                {boxId}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div
                                        className="main  p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "80px" }}
                                        id="m10"
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            M10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 10 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 2 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 2 + colIndex + 1; // 2 boxes per row
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`m10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {/* N01 to N012  */}
                            <div className="d-flex flex-column">
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n01'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N01
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n01_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n02'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N02
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n02_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n03'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N03
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n03_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n04'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N04
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n04_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n05'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N05
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n05_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n06'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N06
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n06_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-5">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n07'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N07
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n07_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n08'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N08
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n08_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div
                                    className="main ms-5 p-2 bg-light"
                                    style={{ height: "170px", width: "140px" }}
                                >
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n09'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N09
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n09_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n10'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N10
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n10_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="d-flex ms-4">
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n11'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N11
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n11_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                    <div
                                        className="main p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                        style={{ fontSize: "10px", width: "140px" }} id='n12'
                                    >
                                        <span
                                            className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                            style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                        >
                                            N12
                                        </span>

                                        {/* Dynamic Rows and Boxes */}
                                        {Array.from({ length: 5 }).map((_, rowIndex) => (
                                            <div className="d-flex" key={rowIndex}>
                                                {Array.from({ length: 4 }).map((_, colIndex) => {
                                                    const boxId = rowIndex * 4 + colIndex + 1;
                                                    return (
                                                        <div
                                                            key={boxId}
                                                            id={`n12_${boxId}`}
                                                            className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                            style={{ height: "5vh", width: "30px" }}
                                                        >
                                                            {boxId}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                            {/* O01 to O07 */}
                            <div className="d-flex flex-column">
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='o01'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O01
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o01_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='o02'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O02
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o02_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='o03'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O03
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o03_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }}
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }} id='o04'
                                    >
                                        O04
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o04_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='008'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O05
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`008_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='o06'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O06
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o06_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div
                                    className="main ms-5 p-2 d-flex flex-column bg-dark border-light border border-1 position-relative"
                                    style={{ fontSize: "10px", width: "140px" }} id='o07'
                                >
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        O07
                                    </span>

                                    {/* Dynamic Rows and Boxes */}
                                    {Array.from({ length: 5 }).map((_, rowIndex) => (
                                        <div className="d-flex" key={rowIndex}>
                                            {Array.from({ length: 4 }).map((_, colIndex) => {
                                                const boxId = rowIndex * 4 + colIndex + 1;
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={`o07_${boxId}`}
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px" }}
                                                    >
                                                        {boxId}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        {/* stack row */}
                        <div className="d-flex">
                            <div className='position-relative ' style={{ marginLeft: "750px" }}>

                                <span className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 rounded"
                                    style={{
                                        zIndex: 1, backdropFilter: "blur(1px)",
                                        width: "100px"
                                    }} id='s1'>
                                    S1
                                </span>
                            </div>
                            <div className='position-relative' style={{ marginLeft: "947px" }}>

                                <span className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 rounded"
                                    style={{
                                        zIndex: 1, backdropFilter: "blur(1px)",
                                        width: "80px"
                                    }} id='s2'>
                                    S2
                                </span>
                            </div>
                            <div className='position-relative' style={{ marginLeft: "1045px" }}>

                                <span className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 rounded"
                                    style={{
                                        zIndex: 1, backdropFilter: "blur(1px)",
                                        width: "50px"
                                    }} id='s3'>
                                    S3
                                </span>
                            </div>
                            <div className='position-relative' style={{ marginLeft: "995px" }}>

                                <span className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 rounded"
                                    style={{
                                        zIndex: 1, backdropFilter: "blur(1px)",
                                        width: "70px"
                                    }} id='s4'>
                                    S4
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        </>
    )
}
