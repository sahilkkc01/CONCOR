import React, { useState } from "react";

export default function GsRakeFrame() {

    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                overflow: "hidden",
                margin: "0",
                padding: "0",
                position: "relative",
                backgroundColor: "#f0f0f0",
            }}
        >
            {/* Zoom Controls */}
            <div
                style={{
                    position: "absolute",
                    top: "10px",
                    right: "10px",
                    zIndex: 1000,
                    display: "flex",
                    gap: "10px",
                }}
            >

            </div>

            {/* Map Iframe with Zoom */}



            <div
                style={{
                    width: "100%",
                    height: "100vh",

                    transformOrigin: "top right", // Maintain origin for scaling

                }}
                className="m-auto"
            >
                <iframe
                    src="/GsRake"
                    style={{
                        width: "100%",
                        height: "100%",
                        border: "1px solid gary",
                    }}
                    title="Map"
                ></iframe>
            </div>
        </div>


    );
}



