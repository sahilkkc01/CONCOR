import React, { useState, useEffect } from 'react'

export default function GsRake() {
    const rows = 4;
    const cols = 5;
    const rows2 = 5; // Number of rows
    const cols2 = 4
    // const totalCells = rows * cols; 
    const numbers = Array.from({ length: rows * cols }, (_, i) => i + 1);
    const [zoomLevel, setZoomLevel] = useState(0.2)// Default Zoomed Out (-0.2 from 1)

    // Zoom In Function
    const handleZoomIn = () => {
        if (zoomLevel < 5) {
            setZoomLevel(prev => prev + 0.2);
        }
    };

    // Zoom Out Function
    const handleZoomOut = () => {
        if (zoomLevel > 0.2) { // Prevents zooming out too much
            setZoomLevel(prev => prev - 0.2);
        }
    };
    // maps fill color
    useEffect(() => {
        const ids = ['za90_1', 'za90_2', 'za90_3', 'za90_8', 'za90_13', 'za90_18', 'za90_19', 'za90_20']; // IDs list
        ids.forEach(id => {
            const element = document.getElementById(id);
            console.log(id);
            console.log(element);
            if (element) {
                element.style.setProperty('background-color', '#8f51dd', 'important');

            }
        });
    }, []);
    return (
        <>
            <div className="m-auto vh-100 vw-100">
                <div className="d-flex gap-3 p-2 bg-light shadow position-fixed top-0 start-50 translate-middle-x rounded mt-2 z-3">
                    <button
                        onClick={handleZoomIn}
                        className="btn btn-success"
                    >
                        +
                    </button>
                    <button
                        onClick={handleZoomOut}
                        className="btn btn-danger"
                    >
                        -
                    </button>
                </div>
                <div className="position-absolute top-0 start-0 w-100 h-100 bg-center"
                    style={{
                        backgroundSize: 'cover',
                        transform: `scale(${zoomLevel})`,
                        transformOrigin: 'center center',
                        transition: 'transform 0.3s ease-in-out',
                    }}>
                    <h1 className='text-center mt-2'>GS Rack Warehouse</h1>
                    <div className='d-flex ms-4 mb-0 mt-5'>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="za90"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZA90
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `za90_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>

                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="za91"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZA91
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `za91_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main" style={{ marginRight: "150px" }}
                        >

                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zb90"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZB90
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zb90_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zb91"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZB91
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zb91_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zb92"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZB92
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zb92_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className=" bg-light" style={{ height: "20vh", width: "20em", marginRight: "150px" }} ></div>

                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zd90"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZD90
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zd90_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zd91"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZD91
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zd91_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zd92"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZD92
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zd92_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className=" bg-light" style={{ height: "20vh", width: "20em", marginRight: "180px" }} ></div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zf90"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZF90
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zf90_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zf91"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZF91
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zf91_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zf92"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZF92
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zf92_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className=" bg-light" style={{ marginRight: "180px" }} ></div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zh90"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZH90
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zh90_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zh91"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZH91
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zh91_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                            {/* Centered Label */}
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                id="zh92"
                                style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                            >
                                ZH92
                            </span>

                            {/* Dynamic Grid */}
                            {Array.from({ length: rows }).map((_, rowIndex) => (
                                <div key={rowIndex} className="d-flex">
                                    {Array.from({ length: cols }).map((_, colIndex) => {
                                        const num = rowIndex * cols + colIndex + 1;
                                        const boxId = `zh92_${num}`; // Generate unique ID for each box
                                        return (
                                            <div
                                                key={boxId}
                                                id={boxId} // Assign unique ID
                                                className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                            >
                                                {num} {/* Display box number */}
                                            </div>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                    </div>
                    {/* second section */}
                    <div className="second_section d-flex">
                        <div className="main" style={{ marginLeft: "350px" }}></div>
                        <div id='s1' className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                            >
                                S1
                            </span>
                        </div>
                        <div className="main " style={{ marginLeft: "560px" }}></div>
                        <div id='s2' className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                            >
                                S2
                            </span>
                        </div>
                        <div className="main" style={{ marginLeft: "550px" }}></div>
                        <div id='s3' className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                            >
                                S3
                            </span>
                        </div>
                        <div className="main" style={{ marginLeft: "550px" }}></div>
                        <div id='s4' className="col-md-2 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                            >
                                S4
                            </span>
                        </div>
                        <div className="main" style={{ marginLeft: "320px" }}></div>
                        <div className="last column">

                            <div className="d-flex">
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i15"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I15
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i15_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i16"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I16
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i16_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>


                            </div>
                            <div className="d-flex">

                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i13"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I13
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i13_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i14"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I14
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i14_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                            </div>
                            <div className="d-flex">
                                <div className="" style={{ height: "150px" }}>

                                </div>
                                <div className="">

                                </div>

                            </div>
                            <div className="d-flex">

                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i10"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I10
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i10_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i11"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I11
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i11_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                            </div>
                            <div className="d-flex">
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i8"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I8
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i8_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i9"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I9
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i9_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                            </div>

                            <div className="d-flex">
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i5"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I5
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i5_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i6"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I6
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i6_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                            </div>

                            <div className="d-flex">
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i3"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I3
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i3_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>
                                <div className="main py-1 px-1 bg-dark d-flex flex-column border-light border border-2 position-relative">
                                    {/* Centered Label */}
                                    <span
                                        className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                        id="i4"
                                        style={{ zIndex: 1, backdropFilter: "blur(1px)" }}
                                    >
                                        I4
                                    </span>

                                    {/* Dynamic Grid */}
                                    {Array.from({ length: rows2 }).map((_, rowIndex) => (
                                        <div key={rowIndex} className="d-flex">
                                            {Array.from({ length: cols2 }).map((_, colIndex) => {
                                                const num = rowIndex * cols2 + colIndex + 1;
                                                const boxId = `i4_${num}`; // Generate unique ID for each box
                                                return (
                                                    <div
                                                        key={boxId}
                                                        id={boxId} // Assign unique ID
                                                        className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                        style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                    >
                                                        {num} {/* Display box number */}
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    ))}
                                </div>

                            </div>

                        </div>

                        <div className="col-md-1 bg-secondary border border-light rounded position-relative" style={{ height: '5vh', width: "6em" }}>
                            <span
                                className="position-absolute top-50 start-50 translate-middle text-center text-white bg-dark bg-opacity-75 px-2  rounded"
                                id='s5' style={{ zIndex: 1, backdropFilter: 'blur(1px)' }}
                            >
                                S5
                            </span>
                        </div>
                        <div className="last_section d-flex flex-column">
                            <div className="bg-light" style={{ height: "150px" }}></div>
                            <div
                                className="main py-1 px-1 d-flex flex-column border-light border border-2 position-relative"
                                style={{ width: "70px", height: "160px", position: "relative" }}
                                id="i12"
                            >
                                <span
                                    className="position-absolute text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    style={{
                                        top: "50%", // Center vertically
                                        left: "50%", // Center horizontally
                                        transform: "translate(-50%, -50%)", // Adjust alignment
                                        zIndex: 1,
                                        backdropFilter: "blur(1px)",
                                    }}
                                >
                                    I12
                                </span>

                                {/* Dynamic Rows and Boxes */}
                                {Array.from({ length: 10 }).map((_, rowIndex) => (
                                    <div className="d-flex bg-dark" key={rowIndex}>
                                        {Array.from({ length: 2 }).map((_, colIndex) => {
                                            const boxNumber = rowIndex * 2 + colIndex + 1; // Calculate box number
                                            if (boxNumber > 20) return null; // Stop at 20
                                            const boxId = `i12_${boxNumber}`; // Generate unique ID
                                            return (
                                                <div
                                                    key={boxId}
                                                    id={boxId} // Assign unique ID
                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                    style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                >
                                                    {boxNumber}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>
                            <div
                                className="main py-1 px-1 d-flex flex-column border-light border border-2 position-relative"
                                style={{ width: "70px", height: "160px", position: "relative", marginTop: "137px" }}
                                id="i7"
                            >
                                <span
                                    className="position-absolute text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    style={{
                                        top: "50%", // Center vertically
                                        left: "50%", // Center horizontally
                                        transform: "translate(-50%, -50%)", // Adjust alignment
                                        zIndex: 1,
                                        backdropFilter: "blur(1px)",
                                    }}
                                >
                                    I7
                                </span>

                                {/* Dynamic Rows and Boxes */}
                                {Array.from({ length: 10 }).map((_, rowIndex) => (
                                    <div className="d-flex bg-dark" key={rowIndex}>
                                        {Array.from({ length: 2 }).map((_, colIndex) => {
                                            const boxNumber = rowIndex * 2 + colIndex + 1; // Calculate box number
                                            if (boxNumber > 20) return null; // Stop at 20
                                            const boxId = `i7_${boxNumber}`; // Generate unique ID
                                            return (
                                                <div
                                                    key={boxId}
                                                    id={boxId} // Assign unique ID
                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                    style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                >
                                                    {boxNumber}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>
                            <div
                                className="main py-1 px-1 d-flex flex-column border-light border border-2 position-relative"
                                style={{ width: "70px", height: "160px", position: "relative", marginTop: "137px" }}
                                id="i2"
                            >
                                <span
                                    className="position-absolute text-center text-white bg-dark bg-opacity-75 px-3 py-1 rounded"
                                    style={{
                                        top: "50%", // Center vertically
                                        left: "50%", // Center horizontally
                                        transform: "translate(-50%, -50%)", // Adjust alignment
                                        zIndex: 1,
                                        backdropFilter: "blur(1px)",
                                    }}
                                >
                                    I2
                                </span>

                                {/* Dynamic Rows and Boxes */}
                                {Array.from({ length: 10 }).map((_, rowIndex) => (
                                    <div className="d-flex bg-dark" key={rowIndex}>
                                        {Array.from({ length: 2 }).map((_, colIndex) => {
                                            const boxNumber = rowIndex * 2 + colIndex + 1; // Calculate box number
                                            if (boxNumber > 20) return null; // Stop at 20
                                            const boxId = `i2_${boxNumber}`; // Generate unique ID
                                            return (
                                                <div
                                                    key={boxId}
                                                    id={boxId} // Assign unique ID
                                                    className="bg-secondary border border-light rounded text-white d-flex align-items-center justify-content-center"
                                                    style={{ height: "5vh", width: "30px", fontSize: "10px" }}
                                                >
                                                    {boxNumber}
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))}
                            </div>


                        </div>

                    </div>
                </div>
            </div>


        </>
    )
}
