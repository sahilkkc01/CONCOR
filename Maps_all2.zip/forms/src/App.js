import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";
import Form1 from "./pages/Form1";
import Form2 from "./pages/Form2";
import APIForm from "./pages/Apifrom";
import Form3 from "./pages/Form3";
import Form4 from "./pages/Form4";
import Form5 from "./pages/Form5";
import TrainWagons from "./Test/Wagon";
import SweetAlert from "./Test/SweetAlert";

import Map from "./mezzanine ground floor/Map";
import MezzanineFloor from "./mezzanine ground floor/MezzanineFloor";
import Mezzanine from "./mezzanine ground floor/Mezzanine";

import EMap from "./export warehouse/EMap";
import ExportMap from "./export warehouse/ExportMap";
import GsRake from "./gs rake warehouse/GsRake";
import Page from "./Page";
import OldLcl from "./old lcl/OldLcl";
import Url from "./Url";
import GsRakeFrame from "./gs rake warehouse/GsRakeFrame";
import OldLclFrame from "./old lcl/OldLclFrame";
import MapFrame from "./mezzanine ground floor/MapFrame";



function App() {
  return (
    <Router>

      <Routes>
        <Route path="/page" element={<Page />} />
        <Route path="/url" element={<Url />} />

        {/* Warehouse Maps */}
        {/* Export Warehouse */}
        <Route path="/EMap" element={<EMap />} />
        <Route path="/" element={<ExportMap />} />
        {/* GsRake */}
        <Route path="/GsRake" element={<GsRake />} />
        <Route path="/GsRakeFrame" element={<GsRakeFrame />} />
        {/* OldLcl */}
        <Route path="/OldLcl" element={<OldLcl />} />
        <Route path="/OldLclFrame" element={<OldLclFrame />} />

        <Route path="/map" element={<Map />} />
        <Route path="/mapFrame" element={<MapFrame />} />

        <Route path="/MezzanineFloor" element={<MezzanineFloor />} />
        <Route path="/Mezzanine" element={<Mezzanine />} />

        {/* <Route path="/Wagon" element={<TrainWagons />} />
        <Route path="/SweetAlert" element={<SweetAlert />} /> */}
        {/* <Route path="/Form2" element={<Form2 />} />
        <Route path="/Form3" element={<Form3 />} />
        <Route path="/Form4" element={<Form4 />} />
        <Route path="/Form5" element={<Form5 />} />
        <Route path="/Apiform" element={<APIForm />} /> */}
      </Routes>

    </Router>
  );
}
export default App;